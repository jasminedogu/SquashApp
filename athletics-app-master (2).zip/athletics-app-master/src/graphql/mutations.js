/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createCheckin = /* GraphQL */ `
  mutation CreateCheckin(
    $input: CreateCheckinInput!
    $condition: ModelCheckinConditionInput
  ) {
    createCheckin(input: $input, condition: $condition) {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
export const updateCheckin = /* GraphQL */ `
  mutation UpdateCheckin(
    $input: UpdateCheckinInput!
    $condition: ModelCheckinConditionInput
  ) {
    updateCheckin(input: $input, condition: $condition) {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
export const deleteCheckin = /* GraphQL */ `
  mutation DeleteCheckin(
    $input: DeleteCheckinInput!
    $condition: ModelCheckinConditionInput
  ) {
    deleteCheckin(input: $input, condition: $condition) {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
