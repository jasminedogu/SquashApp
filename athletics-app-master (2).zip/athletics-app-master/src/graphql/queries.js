/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getCheckin = /* GraphQL */ `
  query GetCheckin($id: ID!) {
    getCheckin(id: $id) {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
export const listCheckins = /* GraphQL */ `
  query ListCheckins(
    $filter: ModelCheckinFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listCheckins(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        mood
        battery
        muscles
        mind
        composure
        confidence
        arousal
        readiness
        chat
        chatWith
        additionalThoughts
        createdAt
        updatedAt
      }
      nextToken
    }
  }
`;
