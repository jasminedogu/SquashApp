/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateCheckin = /* GraphQL */ `
  subscription OnCreateCheckin {
    onCreateCheckin {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
export const onUpdateCheckin = /* GraphQL */ `
  subscription OnUpdateCheckin {
    onUpdateCheckin {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
export const onDeleteCheckin = /* GraphQL */ `
  subscription OnDeleteCheckin {
    onDeleteCheckin {
      id
      mood
      battery
      muscles
      mind
      composure
      confidence
      arousal
      readiness
      chat
      chatWith
      additionalThoughts
      createdAt
      updatedAt
    }
  }
`;
