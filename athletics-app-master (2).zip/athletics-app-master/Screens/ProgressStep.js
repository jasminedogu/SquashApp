import React, { Component } from 'react';
import { View } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';


const FancyProgressStep = React.forwardRef((props, ref) => (
    <View style={{ margin: 20 }}>
      { props.children }
    </View>
));


export default FancyProgressStep;