import React, { useState } from 'react';
import { View } from "react-native";
import { Container, Button, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';
import ProgressStepHeader from './ProgressStepHeader';
import * as Progress from 'react-native-progress';
import { API } from "aws-amplify";
import { createCheckin } from '../src/graphql/mutations';

const StepWrapper = (component) => {
  return (
    { component }
  )

}

const ProgressSteps = ({ children, ...props }) => {

  const [currentStep, setCurrentStep] = useState(0)

  const currentStepComponent = children.find((child, i) => currentStep == i ? child : null)

  async function submitForm() {
    const newCheckin = await API.graphql({ query: createCheckin,
                                                      variables: {input: props.answers}});
  }

  return (
    <View style={{ display: "flex", flex: 1 }}>
      <ProgressStepHeader title={currentStepComponent.props.label} />
      <Progress.Bar style={{ alignSelf: "center", margin: 40 }} progress={currentStep / children.length} width={200} />
      <Container style={{ borderColor: "red", flex: 6 }}>
        {currentStepComponent}
      </Container>
      <Container style={{ margin: "10% 0%", flex: 1, display: "flex", flexDirection: "row", justifyContent: "space-between" }}>
        <Button disabled={currentStep == 0} onPress={() => setCurrentStep(Math.max(currentStep - 1, 0))}>
          <Text>
            Back
          </Text>
        </Button>
        {
          currentStep == children.length - 1 ? (
            <Button style={{backgroundColor: "#232D4B"}} onPress={submitForm}>
              <Text>
                Finish
              </Text>
            </Button>

          ) : (
              <Button disabled={currentStep == children.length - 1} onPress={() => setCurrentStep(Math.min(currentStep + 1, children.length))}>
                <Text>
                  Next
            </Text>
              </Button>

            )
        }
        </Container>
      </View>
  );
}

export default ProgressSteps;
