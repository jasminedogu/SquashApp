import React, { useState } from "react";
import { View, StyleSheet } from "react-native";

import ProgressSteps from './ProgressSteps';
import ProgressStep from './ProgressStep';
import Questions from './Questions';

import { FontAwesome } from '@expo/vector-icons';
// Icons for each tab can be found from https://expo.github.io/vector-icons/
//After creating the TabIcon, you need to add it to your static navigationOptions as shown below


const TabIcon = (props) => (
  <FontAwesome
    name={'info'}
    size={30}
    color={props.focused ? 'grey' : 'darkgrey'}
  />
)

const ScreenOne = () => {

  const navigationOptions = {
    tabBarIcon: TabIcon
  };


  const [answers, setAnswers] = useState({})

  const handleChange = (key) => (value) => {
    console.log(answers);
    setAnswers({
      ...answers,
      [key]: value,
    })
  }

  return (
    <View style={{ flex: 1 }}>
      <ProgressSteps answers = {answers}>
      <ProgressStep label="Physical Attributes">
        <View >
          <Questions.One currentValue={answers["mood"]} onPress={handleChange("mood")} />
        </View>
        </ProgressStep>
        <ProgressStep label="Physical Attributes">
          <View >
            <Questions.Two currentValue={answers["battery"]} onPress={handleChange("battery")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Physical Attributes">
          <View>
            <Questions.Three currentValue={answers["muscles"]} onPress={handleChange("muscles")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Emotional & Mental Attributes">
          <View>
            <Questions.Four currentValue={answers["mind"]} onPress={handleChange("mind")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Emotional & Mental Attributes">
          <View>
            <Questions.Five currentValue={answers["composure"]} onPress={handleChange("composure")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Emotional & Mental Attributes">
          <View>
            <Questions.Six currentValue={answers["confidence"]} onPress={handleChange("confidence")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Overall Readiness">
          <View>
            <Questions.Seven currentValue={answers["arousal"]} onValueChange={handleChange("arousal")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Overall Readiness">
          <View>
            <Questions.Eight currentValue={answers["readiness"]} onPress={handleChange("readiness")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Intervention and Help">
          <View>
            <Questions.Nine currentValue={answers["chat"]} onPress={handleChange("chat")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Intervention and Help">
          <View>
            <Questions.NineFollowUp currentValue={answers["chatWith"]} onPress={handleChange("chatWith")} />
          </View>
        </ProgressStep>
        <ProgressStep label="Intervention and Help">
          <View>
            <Questions.Ten currentValue={answers["additionalThoughts"]} onPress={handleChange("additionalThoughts")} />
          </View>
        </ProgressStep>
      </ProgressSteps>
    </View>
  );
}

ScreenOne['navigationOptions'] = screenProps => ({
  tabBarIcon: TabIcon
})

export default ScreenOne
