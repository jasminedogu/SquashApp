import React, { Component } from 'react';
import { View } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';

const options = [
  "Ready",
  "Not Ready",
]
const QuestionEight = ({ onPress, currentValue }) => {

  return (
    <View>
      <Text>Overall, how ready do you feel to perform to the best of your ability?</Text>
      {
        options.map(option => (
          <ListItem key={option} onPress={() => onPress(option)}>
            <Left>
              <Text>{option}</Text>
            </Left>
            <Right>
              <Radio selected={option == currentValue} />
            </Right>
          </ListItem>
        ))
      }
    </View>
  );
}

export default QuestionEight;
