import React, { Component } from 'react';
import { View } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';

const options = [
  "High",
  "Low",
]
const QuestionSix = ({ onPress, currentValue }) => {

  return (
    <View>
      <Text>How confident do you feel?</Text>
      {
        options.map(option => (
          <ListItem key={option} onPress={() => onPress(option)}>
            <Left>
              <Text>{option}</Text>
            </Left>
            <Right>
              <Radio selected={option == currentValue} />
            </Right>
          </ListItem>
        ))
      }
    </View>
  );
}

export default QuestionSix;
