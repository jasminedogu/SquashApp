import React, { Component } from 'react';
import { View } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';

const options = [
  "Head Coach",
  "Assistant Coach",
  "Captain",
  "Teammate",
]
const QuestionNineFollowUp = ({ onPress, currentValue }) => {

  const _currentValue = currentValue || []

  const handlePress = value => {
    if(!_currentValue.includes(value)) {
      onPress([..._currentValue, value])
    } else {
      onPress(_currentValue.filter(option => option != value))

    }
  }

  return (
    <View>
      <Text>Check all the people who you would like to chat with</Text>
      {
        options.map(option => (
          <ListItem key={option} onPress={() => handlePress(option)}>
            <Left>
              <Text>{option}</Text>
            </Left>
            <Right>
              <Radio selected={_currentValue.includes(option)} />
            </Right>
          </ListItem>
        ))
      }
    </View>
  );
}

export default QuestionNineFollowUp;
