import React, { Component } from 'react';
import { View } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';
import Slider from '@react-native-community/slider';

const options = [
  "Charged",
  "Empty",
]
const QuestionSeven = ({ onValueChange, currentValue }) => {

  return (
    <View>
      <Text>How aroused do you feel?</Text>
      <View style={{ display: "flex", flex: 1, marginTop: 50, marginLeft: 20, marginRight: 20,flexDirection: "row" }}>
        <View style={{
                flex: 1,
                height: 50,
        }}>
          <Text style={{ width: 100}}>Under arousal</Text>
        </View>
        <View style={{ width: 100, flex: 3 }}>
          <Slider
            style={{ width: 200, height: 40 }}
            minimumValue={0}
            maximumValue={1}
            onValueChange={onValueChange}
            minimumTrackTintColor="#FF4D00"
            maximumTrackTintColor="#232D4B"
          />
        </View>
        <View style={{
                flex: 1,
                height: 50,
        }}>
          <Text>Over arousal</Text>

        </View>

      </View>


    </View>
  );
}

export default QuestionSeven;
