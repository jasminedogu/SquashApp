import React, { Component } from 'react';
import { View, TextInput, Keyboard } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left, Textarea } from 'native-base';

const options = [
  "Composed",
  "Distracted",
]
const QuestionTen = ({ onPress, currentValue }) => {
  return (
    <View>
      <Text>Additional Thoughts?</Text>
      <TextInput 
        onBlur={console.log("blur")} 
        style={{ backgroundColor: "#DEDEDE", margin: 20}} rowSpan={6} 
        onEndEditing={console.log("end editing")} />
    </View>
  );
}

export default QuestionTen;
