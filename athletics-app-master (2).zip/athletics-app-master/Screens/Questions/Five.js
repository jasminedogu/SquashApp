import React, { Component } from 'react';
import { View } from "react-native";
import { Container, Header, Content, ListItem, Text, Radio, Right, Left } from 'native-base';

const options = [
  "Very Composed",
  "Distracted",
]
const QuestionFive = ({ onPress, currentValue }) => {
  return (
    <View>
      <Text>How composed do you feel?</Text>
      {
        options.map(option => (
          <ListItem key={option} onPress={() => onPress(option)}>
            <Left>
              <Text>{option}</Text>
            </Left>
            <Right>
              <Radio selected={option == currentValue} />
            </Right>
          </ListItem>
        ))
      }
    </View>
  );
}

export default QuestionFive;
