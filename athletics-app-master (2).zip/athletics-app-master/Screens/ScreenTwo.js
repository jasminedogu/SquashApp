 import { Ionicons } from '@expo/vector-icons';
 import ScreenName from '../components/ScreenName.js'
 import { StyleSheet, View, Button, Alert, AppRegistry, TextInput, Text } from 'react-native';
 import React, { Component } from 'react';
 import { FontAwesome } from '@expo/vector-icons';

 import { API, graphqlOperation} from 'aws-amplify'
 import { createCheckin } from '../src/graphql/mutations'
 import { listCheckins } from '../src/graphql/queries'

 // To create each icon
 //<Ionicons /> always needs size, color, and name
 //props.focused indicates if the page is selected or not


 const TabIcon = (props) => (
   <FontAwesome
     name={'line-chart'}
     size={30}
     color={props.focused ? 'grey' : 'darkgrey'}
   />
 )

 export default class ScreenTwo extends React.Component {

   static navigationOptions = {
     tabBarIcon: TabIcon
   };

   state = {
    name: '',
    checkins:[]
  }

   async listCheckinsByName() {
    try { {/* is there a better way to do state */}
      console.log(this.state.name)
      const checkinData = await API.graphql(graphqlOperation(listCheckins, {filter: {name: {eq: this.state.name}}}))
      const checkins = checkinData.data.listCheckins.items
      this.setState({checkins: checkins})
      this.handleName('')
      console.log("Made it!")
    } catch (err) {console.log(err.message)} }

  handleName = (text) => {
    this.setState({ name: text })
  }

   render() {
     return (
       <View style={styles.container}>
       <TextInput style = {styles.input}
            placeholder = "ex: 8"
            onChangeText= {this.handleName}
            value = {this.state.name}/>
        <View style={styles.buttonContainer}>
          <Button onPress={this.listCheckinsByName.bind(this)} title="Show Me My Data" color="#FFFFFF" accessibilityLabel="Tap on Me"/>
        </View>
        {
        this.state.checkins.map((checkin, index) => (
          <View key = {checkin.id ? checkin.id : index}>
            <Text>Name: {checkin.name}</Text>
            <Text>Sleep: {checkin.sleep} hours</Text>
            <Text>Mood: {checkin.mood}</Text>
          </View>
        ))
      }
      </View>
     );
   }
 }

 const styles = StyleSheet.create({
   container: {
    flex: 1,
    margin:25,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF'
  },
  buttonContainer: {
    backgroundColor: '#6495ed',
    borderRadius: 10,
    padding: 10,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 3
    },
    shadowRadius: 10,
    shadowOpacity: 0.25
  },
  text: {
    color:"black",
    marginTop:20,
    alignSelf:"flex-start",
  },
  input: {
    width: "100%", 
    margin: 15,
    padding: 10,
    height: 40,
    borderColor: '#000000',
    borderWidth:1,
    borderRadius: 15
  },
 });
