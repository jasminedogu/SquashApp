import React, { Component } from "react";
import { Container, Header, Title, Button, Icon, Left, Right, Body } from "native-base";
const ProgressStepHeader = ({ title, ...props}) => {
    return (
      <Container style={{flex: 1}}>
        <Header noShadow>
          {/* <Left>
            <Button transparent>
              <Icon name="arrow-back" />
            </Button>
          </Left> */}
          <Body>
            <Title>{ title || "needs title :(" }</Title>
          </Body>
          {/* <Right>
            <Button transparent>
              <Icon name="menu" />
            </Button>
          </Right> */}
        </Header>
      </Container>
    );
}

export default ProgressStepHeader;