import React from 'react';
import AppNavigator from './navigation/AppNavigator'
import Inputs from './inputs.js'

import { StatusBar } from 'expo-status-bar';
import Amplify, { selectInput } from 'aws-amplify'
import config from './aws-exports'
import { withAuthenticator } from "aws-amplify-react-native"
 
Amplify.configure(config)

const App = () => {
  return(
    <AppNavigator />
  );

}
export default withAuthenticator(App, true);
