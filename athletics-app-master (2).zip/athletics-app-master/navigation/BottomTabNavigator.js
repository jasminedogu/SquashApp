import React from 'react';
import {View,Text} from 'react-native';
import { createBottomTabNavigator } from 'react-navigation-tabs';

import ScreenOne from '../Screens/ScreenOne';
import ScreenTwo from '../Screens/ScreenTwo';


const BottomTabNavigator = createBottomTabNavigator({
  Survey: ScreenOne,
  Data: ScreenTwo,
});

export default BottomTabNavigator;
