import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function ScreenName(props) {
  return (
    <Text style = {styles.title}>{props.name}</Text>
  );
}

const styles = StyleSheet.create({
  title: {
    fontSize:30,
    fontWeight:"600",
    marginBottom:20
  }
})
